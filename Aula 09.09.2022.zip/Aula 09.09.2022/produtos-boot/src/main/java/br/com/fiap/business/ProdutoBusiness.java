package br.com.fiap.business;

import java.math.BigDecimal;

import org.springframework.stereotype.Component;

import br.com.fiap.model.CategoriaModel;

@Component
public class ProdutoBusiness {
	
	
	@Autowired
	private CategoriaRepository categoriaRepository;
}

	//Gravar o SKU
	
	private String changeSkuToUpperCase(String sku){
		return sku.toUpperCase();
	}
	
	
	//Adicionar R$ 10 se categoria Smartphone
	//Adicionar R$ 20 se categoria Notebook
	
	private BigDecimal addValueToPreco(CategoriaModel categoriaModel, BigDecimal preco){
	
	CategoriaModel categoria = categoriaRepository.findById(categoriaModel.getIdCategoria().get());

		if ("Smartphone".equals(categoria.getNomeCategoria())){
				preco = preco.add(new BigDecimal(10));
				
		}else if ("Notebook".equals(categoria.getNomeCategoria())) {
			preco = preco.add(new BigDecimal(20));
	}
	return preco;
	
	}
	//N�o permitir produtos que contenham a palavra "teste"

	private void verifyNomeProduto(String nomeProduto) throws ResponseBusiness()
	
		String nome = nomeProduto.toUpperCase();
	
	if(nome.contains("TESTE")) {
		throws new ResponseBusinessException("N�o � poss�vel cadastrar produtos com a palavra teste");
	}
	
	}
	