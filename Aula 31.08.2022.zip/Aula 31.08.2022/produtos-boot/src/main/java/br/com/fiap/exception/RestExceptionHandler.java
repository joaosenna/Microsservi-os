package br.com.fiap.exception;

import org.springframework.web.bind.annotation.RestControllerAdvice;

@RestControllerAdvice
public class RestExceptionHandler {
	
	private static final String UNEXPECTED_ERROR = 
			"Um erro inesperado aconteceu, contate o suporte em suporte-api@fiap.com.br"

	@ExceptionHandler(Exception.class)
	@ResponseStatus(value = HttpStatus.INTERNAL_SERVER_ERROR)
	public ResponseException handleException(HttpServletRequest request, Exception exception){
		return new ResponseException(request, UNEXPECTED_ERROR, exception.getMessage());
		
	}
}

