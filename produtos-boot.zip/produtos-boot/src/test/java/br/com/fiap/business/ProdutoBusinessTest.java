package br.com.fiap.business;

import static org.junit.Assert.*;

import java.math.BigDecimal;
import java.util.Optional;

import org.junit.Before;
import org.junit.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.springframework.boot.test.context.SpringBootTest;

import br.com.fiap.exception.ResponseBusinessException;
import br.com.fiap.model.CategoriaModel;
import br.com.fiap.model.ProdutoModel;
import br.com.fiap.repository.CategoriaRepository;

@SpringBootTest
public class ProdutoBusinessTest {

	@InjectMocks
	public ProdutoBusiness produtoBusiness;

	@Mock
	private CategoriaRepository categoriaRepository;

	@Before
	public void init() {
		MockitoAnnotations.initMocks(this);
	}

	@Test
	public void testChangeSkuToUpperCase() {

		// GIVEN
		String sku = "1223abcf";
		String expected = "1223ABCF";

		// WHEN
		String actual = produtoBusiness.changeSkuToUpperCase(sku);

		// THEN
		assertEquals("Erro ao transformar o SKU em maiúsculo.", expected, actual);

	}

	@Test
	public void testAddValueToPrecoWithCategoriaSmarthphone() {

		// GIVEN
		CategoriaModel categoriaModel = new CategoriaModel(1, "Smartphone");
		BigDecimal preco = new BigDecimal(10);
		BigDecimal expected = new BigDecimal(20);

		// WHEN
		Mockito.when(categoriaRepository.findById(Mockito.anyLong())).thenReturn(Optional.of(categoriaModel));
		BigDecimal actual = produtoBusiness.addValueToPreco(preco, categoriaModel);

		// THEN
		assertEquals("Erro ao adicionar 10 reais caso a categoria seja 'Smartphone'. ", expected, actual);
	}

	@Test
	public void testAddValueToPrecoWithCategoriaNotebook() {

		// GIVEN
		CategoriaModel categoriaModel = new CategoriaModel(1, "Notebook");
		BigDecimal preco = new BigDecimal(10);
		BigDecimal expected = new BigDecimal(30);
		
		// WHEN
		Mockito.when(categoriaRepository.findById(Mockito.anyLong())).thenReturn(Optional.of(categoriaModel));
		BigDecimal actual = produtoBusiness.addValueToPreco(preco, categoriaModel);

		// THEN
		assertEquals("Erro ao adicionar 10 reais caso a categoria seja 'Notebook'. ", expected, actual);
	}

	@Test
	public void testAddValueToPrecoWithoutCategoria() {

		// GIVEN
		CategoriaModel categoriaModel = new CategoriaModel(1, null);
		BigDecimal preco = new BigDecimal(10);
		BigDecimal expected = new BigDecimal(10);

		// WHEN
		Mockito.when(categoriaRepository.findById(Mockito.anyLong())).thenReturn(Optional.of(categoriaModel));
		BigDecimal actual = produtoBusiness.addValueToPreco(preco, categoriaModel);

		// THEN
		assertEquals("Erro ao retornar o preco caso categoria não seja Smartphone ou Notebook", expected, actual);
	}

	@Test(expected = ResponseBusinessException.class)
	public void testVerifiyNomeProdutoWithTeste() throws ResponseBusinessException {

		// GIVEN
		String nomeProduto = "Produto de Teste";

		// WHEN
		produtoBusiness.verifyNomeProduto(nomeProduto);
	}

	@Test
	public void testVerifiyNomeProdutoWithoutTeste() throws ResponseBusinessException {

		// GIVEN
		String nomeProduto = "Produto Normal";

		// WHEN
		produtoBusiness.verifyNomeProduto(nomeProduto);
	}

	@Test
	public void testApplyBusiness() throws ResponseBusinessException {
		
		// GIVEN
		CategoriaModel categoriaModel = new CategoriaModel(1, "Notebook");
		ProdutoModel produtoModel = new ProdutoModel(1, "Produto OK", "1223abcf", "Descrição teste", new BigDecimal(10), "Caractetisticas Teste", categoriaModel, null);
		ProdutoModel expected = new ProdutoModel(1, "Produto OK", "1223ABCF", "Descrição teste", new BigDecimal(30), "Caractetisticas Teste", categoriaModel, null);
		
		// WHEN
		Mockito.when(categoriaRepository.findById(Mockito.anyLong())).thenReturn(Optional.of(categoriaModel));
		ProdutoModel actual = produtoBusiness.applyBusiness(produtoModel);
		
		// THEN
		Mockito.verify(categoriaRepository, Mockito.times(1)).findById(Mockito.anyLong());
		assertEquals(expected.toString(), actual.toString());
	}

}
